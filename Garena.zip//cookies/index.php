<?php 
    header('location: ../../../error/404.html'); 
?>